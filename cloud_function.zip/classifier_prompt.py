CLASSIFIER_PROMPT = '''Classifique a seguinte pergunta em uma categoria entre as três [RH, TI, outro]

Exemplos:

input: 'Como solicitar férias?" output: 'RH'
input: 'Como peço acesso GCP?" output: 'TI'

question: {utterance}'''