from flask import escape, jsonify, Response
from dialogflow_json import response
from classifier_prompt import CLASSIFIER_PROMPT
from typing import Dict, List, Optional, Tuple, Any
from langchain.llms import VertexAI
from langchain.retrievers import GoogleVertexAISearchRetriever
from langchain.chains import RetrievalQAWithSourcesChain
from vertexai.language_models import TextGenerationModel

import os
import re
import json
import vertexai
import functions_framework


PROJECT_ID = os.environ["PROJECT_ID"]
LOCATION_ID = os.environ["LOCATION_ID"]
REGION = os.environ["REGION"]
MODEL = os.environ["MODEL"]

DATA_STORE_ID_1 = os.environ["DATA_STORE_ID_1"]
DATA_STORE_ID_2 = os.environ["DATA_STORE_ID_2"]


def replace_var(string, var):
    pattern = re.compile(r'{utterance}')
    return pattern.sub(var, string)


@functions_framework.http
def entry_point_http(request):
    request_json = request.json
    search_query = request_json.get("text", "")
    headers = {'Content-Type': 'application/json'}
    data_store = get_data_store_from_question(search_query)
    print(f'CLASSIFICATION RESULT: {data_store}')
    if 'RH' in data_store:
        data_store_id = DATA_STORE_ID_1
    elif 'TI' in data_store:
        data_store_id = DATA_STORE_ID_2
    else:
        data_store_id = ''

    qa_response = retrieve_qa_with_sources(search_query, data_store_id)
    print(f'LangChain response: {qa_response}')
    formatted_results = format_response(qa_response)
    response["fulfillment_response"]["messages"][0]["text"]["text"][0] = formatted_results

    return (response, 200, headers)


def retrieve_qa_with_sources(search_query, data_store_id):
    vertexai.init(project=PROJECT_ID, location=REGION)
    llm = VertexAI(model_name=MODEL, temperature=0, top_p=0.2, max_output_tokens=1024)

    if data_store_id != '':
        retriever = GoogleVertexAISearchRetriever(
            project_id=PROJECT_ID, location_id=LOCATION_ID, data_store_id=data_store_id
        )

        retrieval_qa_with_sources = RetrievalQAWithSourcesChain.from_chain_type(
            llm=llm, chain_type="stuff", retriever=retriever
        )

        return retrieval_qa_with_sources({"question": search_query}, return_only_outputs=True)
    else:
        return {
            'answer': 'Eu ainda não sei falar sobre esse assunto, mas você pode abrir um ticket no XPTO para obter informações.'
        }


def format_response(results):
    answer = results['answer']
    sources = results.get('sources', '')
    if sources != '':
        source_uri = sources
    else:
        source_documents = results.get('source_documents', '')
        if source_documents != '':
            source_uri = results['source_documents'][0].metadata['source']
        else:
            source_uri = 'Não encontrei uma fonte para essa pergunta.'
    formatted_response = f"{answer}\nSources: {source_uri}"
    
    return formatted_response

def get_data_store_from_question(search_query):
    vertexai.init(project=PROJECT_ID, location=REGION)
    parameters = {
        "max_output_tokens": 1024,
        "temperature": 0.2,
        "top_p": 0.2,
        "top_k": 40
    }
    model = TextGenerationModel.from_pretrained(MODEL)
    replaced_classifier_prompt = replace_var(CLASSIFIER_PROMPT, search_query)
    response = model.predict(replaced_classifier_prompt, **parameters)

    return response.text
